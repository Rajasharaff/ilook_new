import "./privacy.css";

export function Privacy() {
  return (
    <div className="privacy">
      <h1>Privacy Policy</h1>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eros
        dolor, pharetra nec quam vitae, suscipit pharetra ligula. Fusce in elit
        ac mauris auctor bibendum. Sed bibendum vehicula gravida. Vestibulum
        tempus dolor tellus, viverra hendrerit libero luctus pellentesque. Nulla
        sit amet eros ligula. Nunc finibus nunc sit amet nibh facilisis
        lobortis. Nunc vitae mauris sed metus convallis vulputate non a risus.
        Nulla facilisi.
      </p>
      <p className="privacyTitle">Management of your relationship with the company :</p>
      <p>
        Quisque volutpat, justo id posuere semper, dolor arcu tincidunt est, ac
        convallis nulla nibh a dui. Vestibulum nunc enim, eleifend a urna sed,
        ultrices elementum neque. Duis cursus magna vel magna fringilla rutrum.
        Phasellus accumsan metus vel nunc sodales, eget vehicula lectus dictum.
        Sed ut blandit quam. Mauris lobortis lorem non malesuada maximus. Duis
        nec odio scelerisque, finibus ante vitae, venenatis nulla. Curabitur sit
        amet cursus nisl. Duis eu semper sem. Praesent sollicitudin orci at leo
        varius tempor. In sagittis mi non dolor mollis tincidunt. Donec
        fermentum erat eget purus iaculis consectetur. Morbi sed gravida arcu.
        Sed enim mi, mollis at ex non, consequat pharetra elit. Suspendisse nec
        ante consequat, pulvinar ligula in, imperdiet turpis. Morbi nec
        consectetur ipsum, nec elementum leo. Sed sed felis et massa fringilla
        tincidunt. Nulla rhoncus pretium leo, aliquet efficitur leo ultricies
        et. Nam fringilla nisl vel risus facilisis facilisis. Aliquam dictum,
        mauris nec fringilla congue, lectus est volutpat lectus, eu sagittis
        tellus enim et leo. Donec pretium magna vel ultrices ultrices. Sed
        imperdiet vestibulum tincidunt. Etiam sed velit tortor. Nam non lorem
        convallis, imperdiet lectus in, laoreet lorem. Cras ac odio metus.{" "}
      </p>
      <p className="privacyTitle">Organisation of services and events :</p>
      <p>
        Suspendisse imperdiet molestie lectus. Lorem ipsum dolor sit amet,
        consectetur adipiscing elit. Proin eget purus elementum, fringilla
        lectus in, consectetur ante. In sodales efficitur suscipit. Integer
        laoreet, enim ac ullamcorper malesuada, magna arcu ultricies dolor, nec
        interdum neque purus sed nunc. Nullam ultrices enim eu consequat
        volutpat. Vestibulum pulvinar ex neque, sit amet auctor nisi maximus eu.
        Curabitur sagittis leo posuere mi elementum facilisis. Nam est eros,
        consectetur eu tellus a, aliquet rhoncus magna. Sed fringilla cursus
        hendrerit. Nam tristique tempor quam, eu dictum orci volutpat sed. Nulla
        ligula tortor, eleifend sed metus consectetur, efficitur porttitor nisi.
        Donec semper finibus neque. Praesent tempus convallis est, a sodales
        turpis. Nullam tempus ex dui, ut semper tellus vestibulum a. Curabitur
        vel nunc posuere arcu condimentum ullamcorper. Donec ex dolor, elementum
        quis viverra at, consequat sit amet lacus.
      </p>
      <p className="privacyTitle">Management of requests and applications :</p>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eros
        dolor, pharetra nec quam vitae, suscipit pharetra ligula. Fusce in elit
        ac mauris auctor bibendum. Sed bibendum vehicula gravida. Vestibulum
        tempus dolor tellus, viverra hendrerit libero luctus pellentesque. Nulla
        sit amet eros ligula. Nunc finibus nunc sit amet nibh facilisis
        lobortis. Nunc vitae mauris sed metus convallis vulputate non a risus.
        Nulla facilisi.
      </p>
      <p className="privacyTitle">Communication of your personal data to third parties collaborators and sponsors :</p>
      <p>
        Quisque volutpat, justo id posuere semper, dolor arcu tincidunt est, ac
        convallis nulla nibh a dui. Vestibulum nunc enim, eleifend a urna sed,
        ultrices elementum neque. Duis cursus magna vel magna fringilla rutrum.
        Phasellus accumsan metus vel nunc sodales, eget vehicula lectus dictum.
        Sed ut blandit quam. Mauris lobortis lorem non malesuada maximus. Duis
        nec odio scelerisque, finibus ante vitae, venenatis nulla. Curabitur sit
        amet cursus nisl. Duis eu semper sem. Praesent sollicitudin orci at leo
        varius tempor. In sagittis mi non dolor mollis tincidunt. Donec
        fermentum erat eget purus iaculis consectetur. Morbi sed gravida arcu.
        Sed enim mi, mollis at ex non, consequat pharetra elit. Suspendisse nec
        ante consequat, pulvinar ligula in, imperdiet turpis. Morbi nec
        consectetur ipsum, nec elementum leo. Sed sed felis et massa fringilla
        tincidunt. Nulla rhoncus pretium leo, aliquet efficitur leo ultricies
        et. Nam fringilla nisl vel risus facilisis facilisis. Aliquam dictum,
        mauris nec fringilla congue, lectus est volutpat lectus, eu sagittis
        tellus enim et leo. Donec pretium magna vel ultrices ultrices. Sed
        imperdiet vestibulum tincidunt. Etiam sed velit tortor. Nam non lorem
        convallis, imperdiet lectus in, laoreet lorem. Cras ac odio metus.{" "}
      </p>
      
    </div>
  );
}
